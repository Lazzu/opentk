//
// Author:
//   Jb Evain (jbevain@gmail.com)
//
// Copyright (c) 2008 - 2015 Jb Evain
//
// Licensed under the MIT/X11 license.
//

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct ("Mono.Cecil")]
[assembly: AssemblyCopyright ("Copyright © 2008 - 2015 Jb Evain")]

[assembly: ComVisible (false)]

[assembly: AssemblyVersion ("0.9.6.0")]
#if !CF
[assembly: AssemblyFileVersion ("0.9.6.0")]
#endif
